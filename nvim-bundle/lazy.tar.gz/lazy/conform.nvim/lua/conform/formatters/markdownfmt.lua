---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/shurcooL/markdownfmt",
    description = "Like gofmt, but for Markdown.",
  },
  command = "markdownfmt",
}
