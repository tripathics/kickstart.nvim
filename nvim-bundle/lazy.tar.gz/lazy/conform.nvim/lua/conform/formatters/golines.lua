---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/segmentio/golines",
    description = "A golang formatter that fixes long lines.",
  },
  command = "golines",
}
