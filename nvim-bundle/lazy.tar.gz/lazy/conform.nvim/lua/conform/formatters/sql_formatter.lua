---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/sql-formatter-org/sql-formatter",
    description = "A whitespace formatter for different query languages.",
  },
  command = "sql-formatter",
}
