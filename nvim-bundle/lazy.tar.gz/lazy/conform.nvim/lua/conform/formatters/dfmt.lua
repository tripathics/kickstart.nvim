---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/dlang-community/dfmt",
    description = "Formatter for D source code.",
  },
  command = "dfmt",
}
