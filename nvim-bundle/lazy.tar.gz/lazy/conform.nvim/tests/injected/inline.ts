foo.innerHTML = `<div> hello </div>`;

bar.innerHTML = `
<div> world </div>
`;

baz.innerHTML = `
  <div> world </div>
  `;

baz.innerHTML = `<div>
  world
</div>`;

baz.innerHTML = `<div>
  world
</div>
`;

baz.innerHTML = `<div>
    world
  </div>
`;
